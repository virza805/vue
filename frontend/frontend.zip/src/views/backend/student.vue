<template>
  <div class="student">
      <h1>Student Page</h1>
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>