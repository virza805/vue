
<!-- 
    
npm install -g @vue/cli |>> https://cli.vuejs.org/guide/installation.html
npm audit fix --force
vue --version

npm update -g @vue/cli

vue create project_dashboard |-> go to create project
cd project_dashboard
npm install vuex@next --save => if needed
npm install vue-router@4 => if needed
npm install => if needed
npm run serve => 


npm run lint --fix
open file .prettierrc and add this "endOfLine": "auto"

"prettier/prettier": ["error", { "endOfLine": "off" }]

npm run lint -- --fix

https://www.chartjs.org/docs/latest/charts/line.html

As your wish sir, Sorry for the late submission. kindly consider my situation. If you want another task, I will submit it on time. But request this task send me Saturday night, cause Sunday my office off day. So, I am waiting for your response. Hope to see you next meeting.

















-->













