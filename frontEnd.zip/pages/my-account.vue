<template>
  <h2 class=" text-4xl text-red-500 font-bold text-center">My Account Page</h2>
</template>

<script>
export default {
  head: {
    title: "My Account",
  },

}
</script>

<style>

</style>
