import Vue from "vue";

import Pagination from 'vue-pagination-2';
// optional style for arrows & dots
// yarn add vue-pagination-2 => https://github.com/matfish2/vue-pagination-2

Vue.component('pagination', Pagination);