<template>
  <div>
      <h2>adminAddTask</h2>
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>