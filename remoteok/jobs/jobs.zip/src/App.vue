
<template>
  <Layout>
    <router-view />
  </Layout>
</template>

<script setup>
import Layout from "@/components/Layout.vue ";


</script>

<style>

</style>