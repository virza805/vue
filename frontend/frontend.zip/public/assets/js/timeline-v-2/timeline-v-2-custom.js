'use strict';
$(document).ready(function(){
    $(function() {
        $('#timeline-2').timeliny({
            hideBlankYears: true
        });
    });
});