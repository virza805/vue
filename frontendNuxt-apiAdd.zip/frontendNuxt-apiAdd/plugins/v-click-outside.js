import Vue from "vue";

import clickOutside from 'v-click-outside'
Vue.use(clickOutside);
