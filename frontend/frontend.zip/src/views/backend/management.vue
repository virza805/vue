<template>
  <div class="management">
      <h1>management</h1>
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>