<?php

namespace App\Http\Controllers;

use App\Models\BookEntry;
use App\Http\Requests\StoreBookEntryRequest;
use App\Http\Requests\UpdateBookEntryRequest;

class BookEntryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\StoreBookEntryRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreBookEntryRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\BookEntry  $bookEntry
     * @return \Illuminate\Http\Response
     */
    public function show(BookEntry $bookEntry)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\BookEntry  $bookEntry
     * @return \Illuminate\Http\Response
     */
    public function edit(BookEntry $bookEntry)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\UpdateBookEntryRequest  $request
     * @param  \App\Models\BookEntry  $bookEntry
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateBookEntryRequest $request, BookEntry $bookEntry)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\BookEntry  $bookEntry
     * @return \Illuminate\Http\Response
     */
    public function destroy(BookEntry $bookEntry)
    {
        //
    }
}
