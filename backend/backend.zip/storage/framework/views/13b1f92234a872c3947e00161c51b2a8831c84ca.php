<h1>Your Change Password token = <?php echo e($token); ?></h1>
<?php /**PATH E:\0namica\htdocs\vue\backend\resources\views/auth/forget_mail.blade.php ENDPATH**/ ?>