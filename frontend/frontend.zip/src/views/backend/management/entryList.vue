<template>
  <div>
    <div class="row">
      <div class="col-12">
        <div class="card">
          <div class="card-header">
            <h4>Entry List</h4>
          </div>
          <div class="card-body table-responsive">
            <table class="table table-bordered table-striped text-center">
              <thead>
                <tr>
                  <th>#</th>
                  <th>Image</th>
                  <th>Name</th>
                  <th>Time</th>
                  <th>Date</th>
                  <th>Return Date</th>
                  <th class="text-center" style="width: 20%">Action</th>
                </tr>
              </thead>
              <tbody class="management-img-entry">
                <tr v-for="i in 5" :key="i">
                  <td>1</td>
                  <td>
                    <img src="/assets/images/auth-bg.jpg" alt="image" />
                  </td>
                  <td>Book</td>
                  <td>11:59 pm</td>
                  <td>12,mar 2021</td>
                  <td>16,mar 2021</td>
                  <td>
                    <div class="d-flex justify-content-end">
                      <a href="#" class="btn btn-sm btn-primary mx-1"
                        >New Entry</a
                      >
                      <a href="#" class="btn btn-sm btn-warning mx-1">Edit</a>
                      <a href="#" class="btn btn-sm btn-danger mx-1">Delete</a>
                    </div>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "bookList",
  methods: {
    getData: function () {},
  },
};
</script>

<style  scoped>
.management-img-entry img{
  width:70px;
}
</style>
