<template>
  <h2 class=" text-4xl text-red-500 font-bold text-center">Checkout Page</h2>
</template>

<script>
export default {
  head: {
    title: "Checkout",
  },

}
</script>

<style>

</style>
