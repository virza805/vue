<h1>Your Change Password token = <?php echo e($token); ?></h1>
<?php /**PATH D:\virza\htdocs\vue\backend\resources\views/auth/forget_mail.blade.php ENDPATH**/ ?>