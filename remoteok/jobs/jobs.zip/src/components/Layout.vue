<template>
<div>
  <Navbar />

  <main>
    <slot />
  </main>
</div>
</template>

<script setup>
import Navbar from './Navbar.vue';

</script>

<style>

</style>