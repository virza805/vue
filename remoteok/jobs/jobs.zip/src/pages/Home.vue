<template>
  <div>
    <suspense>
      
      
    <JobList />
    </suspense>

  </div>
</template>

<script setup>
import JobList from '@/components/JobList.vue';

</script>

<style>

</style>