import Vue from "vue";

import VueSlickCarousel from 'vue-slick-carousel';
// optional style for arrows & dots
// import 'vue-slick-carousel/dist/vue-slick-carousel-theme.css'

Vue.component('vue-slick-carousel', VueSlickCarousel);