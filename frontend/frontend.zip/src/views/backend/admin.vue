<template>
  <div class="admin">
      <h1>Admin Page</h1>
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>